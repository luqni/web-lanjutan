<?php
require_once 'class_acount.php';

$ac1 = new acount ('001', 5000);
$ac2 = new acount ('002', 3000);

//ac1 menabung 500
$ac1->deposit(500);
//ac1 ambil uang 300
$ac1->withdraw(300);
//cetak info
$ac1->cetak();
$ac2->cetak();

?>